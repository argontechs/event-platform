"use client";

import { useActionState } from "react";
import type { CompanyFormState } from "@/lib/companies/actions";
import type { CompanyFormValues } from "@/lib/companies/schema";

type Action = (
  prev: CompanyFormState,
  formData: FormData,
) => Promise<CompanyFormState>;

const initialState: CompanyFormState = { error: "" };

const EMPTY: CompanyFormValues = {
  name: "",
  legalName: "",
  ssmRegNo: "",
  sstRegistered: false,
  sstRegNo: "",
  sstRate: "8.00",
  logoUrl: "",
  brandPrimary: "#c9a35b",
  brandSecondary: "#2a2440",
  brandFont: "",
  addressLine1: "",
  addressLine2: "",
  city: "",
  state: "",
  postcode: "",
  phone: "",
  email: "",
  bankName: "",
  bankAccountName: "",
  bankAccountNo: "",
  duitnowQrUrl: "",
  quotePrefix: "Q",
  invoicePrefix: "INV",
  defaultProfitPercent: "30.00",
  defaultDepositPercent: "50.00",
  defaultLanguage: "EN",
  customDomains: "",
  aiEnabled: true,
  aiModel: "gpt-4o",
};

function Section({ title, hint, children }: { title: string; hint?: string; children: React.ReactNode }) {
  return (
    <fieldset className="rounded-xl border border-white/10 bg-white/[0.02] p-5">
      <legend className="px-2 text-sm font-medium text-accent">{title}</legend>
      {hint ? <p className="mb-3 text-xs text-white/40">{hint}</p> : null}
      <div className="grid gap-4 sm:grid-cols-2">{children}</div>
    </fieldset>
  );
}

function Field({
  name,
  label,
  defaultValue,
  type = "text",
  placeholder,
  error,
  full,
}: {
  name: string;
  label: string;
  defaultValue?: string;
  type?: string;
  placeholder?: string;
  error?: string;
  full?: boolean;
}) {
  return (
    <label className={`flex flex-col gap-1 text-sm ${full ? "sm:col-span-2" : ""}`}>
      <span className="text-white/60">{label}</span>
      <input
        name={name}
        type={type}
        defaultValue={defaultValue}
        placeholder={placeholder}
        className="rounded-md border border-white/15 bg-white/5 px-3 py-2 text-white outline-none focus:border-accent"
      />
      {error ? <span className="text-xs text-red-400">{error}</span> : null}
    </label>
  );
}

export function CompanyForm({
  action,
  initial,
  aiKeySet = false,
  submitLabel,
}: {
  action: Action;
  initial?: CompanyFormValues;
  aiKeySet?: boolean;
  submitLabel: string;
}) {
  const [state, formAction, pending] = useActionState(action, initialState);
  const v = initial ?? EMPTY;
  const fe = state.fieldErrors ?? {};

  return (
    <form action={formAction} className="flex max-w-3xl flex-col gap-5">
      <Section title="Identity">
        <Field name="name" label="Company name" defaultValue={v.name} error={fe.name} />
        <Field name="legalName" label="Legal name (Sdn Bhd)" defaultValue={v.legalName} />
        <Field name="ssmRegNo" label="SSM registration no." defaultValue={v.ssmRegNo} />
        <label className="flex flex-col gap-1 text-sm">
          <span className="text-white/60">Default language</span>
          <select
            name="defaultLanguage"
            defaultValue={v.defaultLanguage}
            className="rounded-md border border-white/15 bg-white/5 px-3 py-2 text-white outline-none focus:border-accent"
          >
            <option value="EN">English</option>
            <option value="MS">Bahasa Malaysia</option>
            <option value="ZH">中文</option>
          </select>
        </label>
      </Section>

      <Section title="SST" hint="Some companies are SST-registered, some are not. This drives quotes & invoices (overridable per document).">
        <label className="flex items-center gap-2 text-sm sm:col-span-2">
          <input type="checkbox" name="sstRegistered" defaultChecked={v.sstRegistered} />
          <span className="text-white/80">This company is SST-registered</span>
        </label>
        <Field name="sstRegNo" label="SST registration no." defaultValue={v.sstRegNo} />
        <Field name="sstRate" label="SST rate (%)" defaultValue={v.sstRate} error={fe.sstRate} />
      </Section>

      <Section title="Branding" hint="Drives the company's site, quotes, invoices and emails.">
        <Field name="logoUrl" label="Logo URL" defaultValue={v.logoUrl} full />
        <Field name="brandPrimary" label="Primary colour (hex)" defaultValue={v.brandPrimary} />
        <Field name="brandSecondary" label="Secondary colour (hex)" defaultValue={v.brandSecondary} />
        <Field name="brandFont" label="Brand font" defaultValue={v.brandFont} />
      </Section>

      <Section title="Contact & address">
        <Field name="email" label="Email" type="email" defaultValue={v.email} error={fe.email} />
        <Field name="phone" label="Phone" defaultValue={v.phone} placeholder="+60 3-1234 5678" />
        <Field name="addressLine1" label="Address line 1" defaultValue={v.addressLine1} full />
        <Field name="addressLine2" label="Address line 2" defaultValue={v.addressLine2} full />
        <Field name="city" label="City" defaultValue={v.city} />
        <Field name="state" label="State" defaultValue={v.state} />
        <Field name="postcode" label="Postcode" defaultValue={v.postcode} />
      </Section>

      <Section title="Payment details" hint="Manual deposit flow — shown to customers on the quote page.">
        <Field name="bankName" label="Bank name" defaultValue={v.bankName} />
        <Field name="bankAccountName" label="Account name" defaultValue={v.bankAccountName} />
        <Field name="bankAccountNo" label="Account number" defaultValue={v.bankAccountNo} />
        <Field name="duitnowQrUrl" label="DuitNow QR image URL" defaultValue={v.duitnowQrUrl} />
      </Section>

      <Section title="Quoting & numbering">
        <Field name="quotePrefix" label="Quote number prefix" defaultValue={v.quotePrefix} error={fe.quotePrefix} />
        <Field name="invoicePrefix" label="Invoice number prefix" defaultValue={v.invoicePrefix} error={fe.invoicePrefix} />
        <Field name="defaultProfitPercent" label="Default profit %" defaultValue={v.defaultProfitPercent} error={fe.defaultProfitPercent} />
        <Field name="defaultDepositPercent" label="Default deposit %" defaultValue={v.defaultDepositPercent} error={fe.defaultDepositPercent} />
      </Section>

      <Section title="Public site" hint="Each company runs on its own custom domain(s). Comma or newline separated.">
        <label className="flex flex-col gap-1 text-sm sm:col-span-2">
          <span className="text-white/60">Custom domains</span>
          <textarea
            name="customDomains"
            defaultValue={v.customDomains}
            rows={2}
            placeholder="acme-events.com, www.acme-events.com"
            className="rounded-md border border-white/15 bg-white/5 px-3 py-2 text-white outline-none focus:border-accent"
          />
        </label>
      </Section>

      <Section title="AI (smart quoting)" hint="OpenAI key is encrypted at rest. Leave blank to keep the existing key.">
        <label className="flex items-center gap-2 text-sm sm:col-span-2">
          <input type="checkbox" name="aiEnabled" defaultChecked={v.aiEnabled} />
          <span className="text-white/80">Enable AI planning & quotation</span>
        </label>
        <Field name="aiModel" label="AI model" defaultValue={v.aiModel} error={fe.aiModel} />
        <Field
          name="aiApiKey"
          label="OpenAI API key"
          type="password"
          placeholder={aiKeySet ? "•••••••• (saved — leave blank to keep)" : "sk-…"}
        />
      </Section>

      {state.error ? (
        <p className="text-sm text-red-400" role="alert">
          {state.error}
        </p>
      ) : null}

      <div>
        <button
          type="submit"
          disabled={pending}
          className="rounded-md bg-accent px-5 py-2.5 font-medium text-ink transition hover:brightness-110 disabled:opacity-60"
        >
          {pending ? "Saving…" : submitLabel}
        </button>
      </div>
    </form>
  );
}
