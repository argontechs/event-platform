"use client";

import { useActionState, useState } from "react";
import {
  updateQuotationAction,
  type QuotationActionState,
} from "@/lib/quotations/actions";
import { computeTotals, unitPrice, lineTotal } from "@/lib/quotations/calc";

export type EditorLine = {
  description: string;
  category: string;
  quantity: number;
  unit: string;
  costPrice: number;
  profitPercent: number;
  referenceImageUrl: string;
};

const initialState: QuotationActionState = { error: "" };

function rm(n: number): string {
  return `RM ${n.toFixed(2)}`;
}

export function QuotationEditor({
  quotationId,
  sstRate,
  initial,
}: {
  quotationId: string;
  sstRate: number;
  initial: {
    lines: EditorLine[];
    profitPercentDefault: number;
    discount: number;
    depositPercent: number;
    sstApplied: boolean;
    notes: string;
  };
}) {
  const [state, formAction, pending] = useActionState(
    updateQuotationAction.bind(null, quotationId),
    initialState,
  );

  const [lines, setLines] = useState<EditorLine[]>(initial.lines);
  const [profitDefault, setProfitDefault] = useState(initial.profitPercentDefault);
  const [discount, setDiscount] = useState(initial.discount);
  const [depositPercent, setDepositPercent] = useState(initial.depositPercent);
  const [sstApplied, setSstApplied] = useState(initial.sstApplied);
  const [notes, setNotes] = useState(initial.notes);

  const totals = computeTotals({
    lines: lines.map((l) => ({
      quantity: l.quantity,
      costPrice: l.costPrice,
      profitPercent: l.profitPercent,
    })),
    discount,
    sstApplied,
    sstRate,
    depositPercent,
  });

  function update(i: number, patch: Partial<EditorLine>) {
    setLines((prev) => prev.map((l, idx) => (idx === i ? { ...l, ...patch } : l)));
  }
  function addLine() {
    setLines((prev) => [
      ...prev,
      { description: "", category: "", quantity: 1, unit: "unit", costPrice: 0, profitPercent: profitDefault, referenceImageUrl: "" },
    ]);
  }
  function removeLine(i: number) {
    setLines((prev) => prev.filter((_, idx) => idx !== i));
  }
  function applyDefaultProfit() {
    setLines((prev) => prev.map((l) => ({ ...l, profitPercent: profitDefault })));
  }

  const num =
    "w-full rounded border border-white/15 bg-white/5 px-2 py-1 text-right text-sm text-white outline-none focus:border-accent";
  const txt =
    "w-full rounded border border-white/15 bg-white/5 px-2 py-1 text-sm text-white outline-none focus:border-accent";

  return (
    <form action={formAction} className="flex flex-col gap-5">
      <input type="hidden" name="lines" value={JSON.stringify(lines)} />

      {/* Lines */}
      <div className="overflow-x-auto rounded-xl border border-white/10">
        <table className="w-full min-w-[760px] text-sm">
          <thead className="bg-white/[0.03] text-left text-xs text-white/50">
            <tr>
              <th className="px-3 py-2 font-medium">Material / item</th>
              <th className="px-3 py-2 font-medium">Qty</th>
              <th className="px-3 py-2 font-medium">Unit</th>
              <th className="px-3 py-2 font-medium text-right">Cost (RM)</th>
              <th className="px-3 py-2 font-medium text-right">Profit %</th>
              <th className="px-3 py-2 font-medium text-right">Sell/unit</th>
              <th className="px-3 py-2 font-medium text-right">Line total</th>
              <th className="px-3 py-2" />
            </tr>
          </thead>
          <tbody>
            {lines.length === 0 ? (
              <tr>
                <td colSpan={8} className="px-3 py-6 text-center text-white/40">
                  No items yet — add a line or generate with AI.
                </td>
              </tr>
            ) : (
              lines.map((l, i) => (
                <tr key={i} className="border-t border-white/5 align-top">
                  <td className="px-3 py-2">
                    <input
                      className={txt}
                      value={l.description}
                      placeholder="e.g. Floral arch"
                      onChange={(e) => update(i, { description: e.target.value })}
                    />
                  </td>
                  <td className="px-3 py-2 w-16">
                    <input
                      type="number"
                      min={0}
                      className={num}
                      value={l.quantity}
                      onChange={(e) => update(i, { quantity: Number(e.target.value) })}
                    />
                  </td>
                  <td className="px-3 py-2 w-20">
                    <input
                      className={txt}
                      value={l.unit}
                      onChange={(e) => update(i, { unit: e.target.value })}
                    />
                  </td>
                  <td className="px-3 py-2 w-24">
                    <input
                      type="number"
                      min={0}
                      step="0.01"
                      className={num}
                      value={l.costPrice}
                      onChange={(e) => update(i, { costPrice: Number(e.target.value) })}
                    />
                  </td>
                  <td className="px-3 py-2 w-20">
                    <input
                      type="number"
                      step="0.1"
                      className={num}
                      value={l.profitPercent}
                      onChange={(e) => update(i, { profitPercent: Number(e.target.value) })}
                    />
                  </td>
                  <td className="px-3 py-2 text-right text-white/70">
                    {rm(unitPrice(l.costPrice, l.profitPercent))}
                  </td>
                  <td className="px-3 py-2 text-right text-white/90">
                    {rm(lineTotal(l.quantity, l.costPrice, l.profitPercent))}
                  </td>
                  <td className="px-3 py-2 text-right">
                    <button
                      type="button"
                      onClick={() => removeLine(i)}
                      className="text-white/40 hover:text-red-400"
                      aria-label="Remove line"
                    >
                      ✕
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      <div className="flex flex-wrap gap-3">
        <button type="button" onClick={addLine} className="rounded-md border border-white/15 px-3 py-1.5 text-sm text-white/80 hover:bg-white/5">
          + Add line
        </button>
        <button type="button" onClick={applyDefaultProfit} className="rounded-md border border-white/15 px-3 py-1.5 text-sm text-white/80 hover:bg-white/5">
          Apply {profitDefault}% to all
        </button>
      </div>

      {/* Settings + totals */}
      <div className="grid gap-5 sm:grid-cols-2">
        <div className="flex flex-col gap-3 rounded-xl border border-white/10 bg-white/[0.02] p-4">
          <label className="flex items-center justify-between gap-3 text-sm">
            <span className="text-white/60">Default profit %</span>
            <input type="number" name="profitPercentDefault" step="0.1" value={profitDefault}
              onChange={(e) => setProfitDefault(Number(e.target.value))} className={`${num} w-28`} />
          </label>
          <label className="flex items-center justify-between gap-3 text-sm">
            <span className="text-white/60">Discount (RM)</span>
            <input type="number" name="discount" step="0.01" value={discount}
              onChange={(e) => setDiscount(Number(e.target.value))} className={`${num} w-28`} />
          </label>
          <label className="flex items-center justify-between gap-3 text-sm">
            <span className="text-white/60">Deposit %</span>
            <input type="number" name="depositPercent" step="0.1" value={depositPercent}
              onChange={(e) => setDepositPercent(Number(e.target.value))} className={`${num} w-28`} />
          </label>
          <label className="flex items-center justify-between gap-3 text-sm">
            <span className="text-white/60">Apply SST ({sstRate}%)</span>
            <input type="checkbox" name="sstApplied" checked={sstApplied}
              onChange={(e) => setSstApplied(e.target.checked)} />
          </label>
          <label className="flex flex-col gap-1 text-sm">
            <span className="text-white/60">Notes</span>
            <textarea name="notes" rows={2} value={notes}
              onChange={(e) => setNotes(e.target.value)} className={txt} />
          </label>
        </div>

        <div className="flex flex-col gap-2 rounded-xl border border-white/10 bg-white/[0.02] p-4 text-sm">
          <Row label="Subtotal" value={rm(totals.subtotal)} />
          <Row label="Discount" value={`− ${rm(totals.discount)}`} />
          {sstApplied ? <Row label={`SST (${sstRate}%)`} value={rm(totals.sstAmount)} /> : null}
          <div className="my-1 border-t border-white/10" />
          <Row label="Total" value={rm(totals.total)} strong />
          <Row label={`Deposit (${depositPercent}%)`} value={rm(totals.depositAmount)} />
          <Row label="Balance" value={rm(totals.balanceDue)} />
        </div>
      </div>

      {state.error ? <p className="text-sm text-red-400">{state.error}</p> : null}
      {state.ok ? <p className="text-sm text-emerald-400">Saved.</p> : null}

      <div>
        <button type="submit" disabled={pending}
          className="rounded-md bg-accent px-5 py-2.5 font-medium text-ink transition hover:brightness-110 disabled:opacity-60">
          {pending ? "Saving…" : "Save quotation"}
        </button>
      </div>
    </form>
  );
}

function Row({ label, value, strong }: { label: string; value: string; strong?: boolean }) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-white/55">{label}</span>
      <span className={strong ? "text-lg font-semibold text-white" : "text-white/85"}>{value}</span>
    </div>
  );
}
