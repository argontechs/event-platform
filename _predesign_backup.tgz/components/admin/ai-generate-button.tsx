"use client";

import { useActionState } from "react";
import { runAiDraftAction, type AiActionState } from "@/lib/quotations/actions";

const initial: AiActionState = { error: "" };

export function AiGenerateButton({ quotationId }: { quotationId: string }) {
  const [state, action, pending] = useActionState(
    runAiDraftAction.bind(null, quotationId),
    initial,
  );

  return (
    <form action={action} className="flex flex-wrap items-center gap-3">
      <button
        type="submit"
        disabled={pending}
        className="rounded-md border border-accent/40 bg-accent/10 px-4 py-2 text-sm font-medium text-accent transition hover:bg-accent/20 disabled:opacity-60"
      >
        {pending ? "Analysing images & drafting…" : "✨ Generate with AI"}
      </button>
      {state.error ? <span className="text-sm text-red-400">{state.error}</span> : null}
      {state.ok ? (
        <span className="text-sm text-emerald-400">Draft applied — edit below.</span>
      ) : null}
    </form>
  );
}
