import Link from "next/link";
import type { Locale } from "@/lib/i18n/config";
import type { Dictionary } from "@/lib/i18n/dictionaries";
import { LanguageSwitcher } from "./language-switcher";

export function SiteNav({
  locale,
  dict,
  brandName,
}: {
  locale: Locale;
  dict: Dictionary["nav"];
  brandName: string;
}) {
  const base = `/${locale}`;
  return (
    <header className="fixed inset-x-0 top-0 z-50 backdrop-blur-md">
      <nav className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
        <Link href={base} className="text-lg font-semibold tracking-tight text-white">
          {brandName}
        </Link>
        <div className="hidden items-center gap-7 text-sm text-white/70 md:flex">
          <Link href={`${base}/services`} className="hover:text-white">{dict.services}</Link>
          <Link href={`${base}/portfolio`} className="hover:text-white">{dict.portfolio}</Link>
          <Link href={`${base}/about`} className="hover:text-white">{dict.about}</Link>
          <Link href={`${base}/contact`} className="hover:text-white">{dict.contact}</Link>
        </div>
        <div className="flex items-center gap-4">
          <LanguageSwitcher current={locale} />
          <Link
            href={`${base}/contact`}
            className="rounded-full px-4 py-2 text-sm font-medium text-ink transition hover:brightness-110"
            style={{ backgroundColor: "var(--brand, #c9a35b)" }}
          >
            {dict.enquire}
          </Link>
        </div>
      </nav>
    </header>
  );
}
