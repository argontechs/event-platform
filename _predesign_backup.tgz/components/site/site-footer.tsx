import type { Dictionary } from "@/lib/i18n/dictionaries";

export function SiteFooter({
  dict,
  brandName,
}: {
  dict: Dictionary["footer"];
  brandName: string;
}) {
  const year = new Date().getFullYear();
  return (
    <footer className="border-t border-white/10 px-6 py-10 text-sm text-white/40">
      <div className="mx-auto flex max-w-6xl flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
        <span className="text-white/70">{brandName}</span>
        <span>{dict.tagline}</span>
        <span>
          © {year} · {dict.rights}
        </span>
      </div>
    </footer>
  );
}
