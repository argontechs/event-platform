"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { locales, localeNames, type Locale } from "@/lib/i18n/config";

export function LanguageSwitcher({ current }: { current: Locale }) {
  const pathname = usePathname();
  const rest = pathname.replace(/^\/(en|ms|zh)(?=\/|$)/, "");

  return (
    <div className="flex items-center gap-1 text-xs">
      {locales.map((l) => (
        <Link
          key={l}
          href={`/${l}${rest || ""}`}
          className={`rounded px-2 py-1 transition ${
            l === current
              ? "bg-white/10 text-white"
              : "text-white/50 hover:text-white"
          }`}
        >
          {localeNames[l]}
        </Link>
      ))}
    </div>
  );
}
