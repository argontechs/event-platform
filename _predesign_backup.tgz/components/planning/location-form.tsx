"use client";

import { useActionState } from "react";
import type { PlanningFormState } from "@/lib/planning/actions";

type Action = (prev: PlanningFormState, fd: FormData) => Promise<PlanningFormState>;

export type LocationValues = {
  name: string;
  addressLine1: string;
  city: string;
  state: string;
  postcode: string;
  capacity: string;
  contactName: string;
  contactPhone: string;
  notes: string;
};

const EMPTY: LocationValues = {
  name: "",
  addressLine1: "",
  city: "",
  state: "",
  postcode: "",
  capacity: "",
  contactName: "",
  contactPhone: "",
  notes: "",
};

const field =
  "w-full rounded-md border border-white/15 bg-white/5 px-3 py-2 text-sm text-white outline-none focus:border-accent";

export function LocationForm({
  action,
  initial,
  submitLabel,
}: {
  action: Action;
  initial?: LocationValues;
  submitLabel: string;
}) {
  const [state, formAction, pending] = useActionState(action, { error: "" });
  const v = initial ?? EMPTY;

  return (
    <form action={formAction} className="grid max-w-2xl gap-4 sm:grid-cols-2">
      <label className="flex flex-col gap-1 text-sm sm:col-span-2">
        <span className="text-white/60">Venue name</span>
        <input name="name" defaultValue={v.name} className={field} />
      </label>
      <label className="flex flex-col gap-1 text-sm sm:col-span-2">
        <span className="text-white/60">Address</span>
        <input name="addressLine1" defaultValue={v.addressLine1} className={field} />
      </label>
      <label className="flex flex-col gap-1 text-sm">
        <span className="text-white/60">City</span>
        <input name="city" defaultValue={v.city} className={field} />
      </label>
      <label className="flex flex-col gap-1 text-sm">
        <span className="text-white/60">State</span>
        <input name="state" defaultValue={v.state} className={field} />
      </label>
      <label className="flex flex-col gap-1 text-sm">
        <span className="text-white/60">Postcode</span>
        <input name="postcode" defaultValue={v.postcode} className={field} />
      </label>
      <label className="flex flex-col gap-1 text-sm">
        <span className="text-white/60">Capacity</span>
        <input name="capacity" type="number" defaultValue={v.capacity} className={field} />
      </label>
      <label className="flex flex-col gap-1 text-sm">
        <span className="text-white/60">Contact name</span>
        <input name="contactName" defaultValue={v.contactName} className={field} />
      </label>
      <label className="flex flex-col gap-1 text-sm">
        <span className="text-white/60">Contact phone</span>
        <input name="contactPhone" defaultValue={v.contactPhone} className={field} />
      </label>
      <label className="flex flex-col gap-1 text-sm sm:col-span-2">
        <span className="text-white/60">Notes</span>
        <textarea name="notes" rows={2} defaultValue={v.notes} className={field} />
      </label>

      {state.error ? <p className="text-sm text-red-400 sm:col-span-2">{state.error}</p> : null}

      <div className="sm:col-span-2">
        <button
          type="submit"
          disabled={pending}
          className="rounded-md bg-accent px-5 py-2.5 font-medium text-ink transition hover:brightness-110 disabled:opacity-60"
        >
          {pending ? "Saving…" : submitLabel}
        </button>
      </div>
    </form>
  );
}
