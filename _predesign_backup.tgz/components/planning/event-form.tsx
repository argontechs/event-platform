"use client";

import { useActionState } from "react";
import type { PlanningFormState } from "@/lib/planning/actions";
import { EVENT_TYPES } from "@/lib/leads/schema";

type Action = (prev: PlanningFormState, fd: FormData) => Promise<PlanningFormState>;

const STATUSES = ["CONFIRMED", "IN_PLANNING", "READY", "EXECUTED", "COMPLETED", "CLOSED", "CANCELLED"] as const;

export type EventValues = {
  title: string;
  eventType: string;
  eventDate: string;
  locationId: string;
  venueText: string;
  totalAmount: string;
  status: string;
};

const EMPTY: EventValues = {
  title: "",
  eventType: "WEDDING",
  eventDate: "",
  locationId: "",
  venueText: "",
  totalAmount: "",
  status: "IN_PLANNING",
};

const field =
  "w-full rounded-md border border-white/15 bg-white/5 px-3 py-2 text-sm text-white outline-none focus:border-accent";

export function EventForm({
  action,
  locations,
  initial,
  submitLabel,
  showStatus = false,
}: {
  action: Action;
  locations: { id: string; name: string }[];
  initial?: EventValues;
  submitLabel: string;
  showStatus?: boolean;
}) {
  const [state, formAction, pending] = useActionState(action, { error: "" });
  const v = initial ?? EMPTY;

  return (
    <form action={formAction} className="grid max-w-2xl gap-4 sm:grid-cols-2">
      <label className="flex flex-col gap-1 text-sm sm:col-span-2">
        <span className="text-white/60">Event title</span>
        <input name="title" defaultValue={v.title} className={field} />
      </label>
      <label className="flex flex-col gap-1 text-sm">
        <span className="text-white/60">Event type</span>
        <select name="eventType" defaultValue={v.eventType} className={field}>
          {EVENT_TYPES.map((t) => (
            <option key={t} value={t}>
              {t.replace("_", " ").toLowerCase()}
            </option>
          ))}
        </select>
      </label>
      <label className="flex flex-col gap-1 text-sm">
        <span className="text-white/60">Date</span>
        <input name="eventDate" type="date" defaultValue={v.eventDate} className={field} />
      </label>
      <label className="flex flex-col gap-1 text-sm">
        <span className="text-white/60">Location</span>
        <select name="locationId" defaultValue={v.locationId} className={field}>
          <option value="">— none —</option>
          {locations.map((l) => (
            <option key={l.id} value={l.id}>
              {l.name}
            </option>
          ))}
        </select>
      </label>
      <label className="flex flex-col gap-1 text-sm">
        <span className="text-white/60">Venue note</span>
        <input name="venueText" defaultValue={v.venueText} className={field} />
      </label>
      <label className="flex flex-col gap-1 text-sm">
        <span className="text-white/60">Budget / total (RM)</span>
        <input name="totalAmount" type="number" step="0.01" defaultValue={v.totalAmount} className={field} />
      </label>
      {showStatus ? (
        <label className="flex flex-col gap-1 text-sm">
          <span className="text-white/60">Status</span>
          <select name="status" defaultValue={v.status} className={field}>
            {STATUSES.map((s) => (
              <option key={s} value={s}>
                {s.replace("_", " ").toLowerCase()}
              </option>
            ))}
          </select>
        </label>
      ) : null}

      {state.error ? <p className="text-sm text-red-400 sm:col-span-2">{state.error}</p> : null}

      <div className="sm:col-span-2">
        <button
          type="submit"
          disabled={pending}
          className="rounded-md bg-accent px-5 py-2.5 font-medium text-ink transition hover:brightness-110 disabled:opacity-60"
        >
          {pending ? "Saving…" : submitLabel}
        </button>
      </div>
    </form>
  );
}
