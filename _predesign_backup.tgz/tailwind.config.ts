import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./src/**/*.{ts,tsx,mdx}"],
  theme: {
    extend: {
      colors: {
        ink: "#0b0b10",
        accent: "#c9a35b", // warm gold — placeholder brand token, overridden per company later
      },
    },
  },
  plugins: [],
};

export default config;
