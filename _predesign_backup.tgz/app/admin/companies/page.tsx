import Link from "next/link";
import { prisma } from "@event/db";
import { requireSuperAdmin } from "@/lib/auth/rbac";

export const dynamic = "force-dynamic";

export default async function CompaniesListPage() {
  await requireSuperAdmin();
  const companies = await prisma.company.findMany({
    orderBy: { name: "asc" },
    select: {
      id: true,
      name: true,
      sstRegistered: true,
      customDomains: true,
      defaultProfitPercent: true,
    },
  });

  return (
    <section>
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold">Companies</h1>
        <Link
          href="/admin/companies/new"
          className="rounded-md bg-accent px-4 py-2 text-sm font-medium text-ink transition hover:brightness-110"
        >
          + New company
        </Link>
      </div>

      <div className="mt-6 overflow-hidden rounded-xl border border-white/10">
        <table className="w-full text-sm">
          <thead className="bg-white/[0.03] text-left text-white/50">
            <tr>
              <th className="px-4 py-3 font-medium">Name</th>
              <th className="px-4 py-3 font-medium">SST</th>
              <th className="px-4 py-3 font-medium">Default profit</th>
              <th className="px-4 py-3 font-medium">Domains</th>
            </tr>
          </thead>
          <tbody>
            {companies.length === 0 ? (
              <tr>
                <td colSpan={4} className="px-4 py-8 text-center text-white/40">
                  No companies yet. Create your first one.
                </td>
              </tr>
            ) : (
              companies.map((c) => (
                <tr key={c.id} className="border-t border-white/5 hover:bg-white/[0.02]">
                  <td className="px-4 py-3">
                    <Link href={`/admin/companies/${c.id}`} className="text-white hover:text-accent">
                      {c.name}
                    </Link>
                  </td>
                  <td className="px-4 py-3 text-white/60">
                    {c.sstRegistered ? "Registered" : "—"}
                  </td>
                  <td className="px-4 py-3 text-white/60">
                    {String(c.defaultProfitPercent)}%
                  </td>
                  <td className="px-4 py-3 text-white/40">
                    {c.customDomains.join(", ") || "—"}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </section>
  );
}
