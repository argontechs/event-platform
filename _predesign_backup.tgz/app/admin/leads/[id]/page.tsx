import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { prisma } from "@event/db";
import { requireUser, isSuperAdmin } from "@/lib/auth/rbac";
import { createQuotationForLead } from "@/lib/quotations/actions";

export const dynamic = "force-dynamic";

export default async function LeadDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const user = await requireUser();

  const lead = await prisma.lead.findUnique({
    where: { id },
    include: { customer: true, attachments: true, quotations: true },
  });
  if (!lead) notFound();
  if (!isSuperAdmin(user) && user.companyId !== lead.companyId) redirect("/admin/leads");

  const images = lead.attachments.filter((a) => a.kind === "REFERENCE");
  const createAction = createQuotationForLead.bind(null, lead.id);

  const facts: [string, string][] = [
    ["Event", lead.eventType.toLowerCase()],
    ["Date", lead.eventDate ? lead.eventDate.toISOString().slice(0, 10) : "—"],
    ["Time", lead.eventTime ?? "—"],
    ["Venue", lead.venueText ?? "—"],
    ["Guests", lead.guestCount ? String(lead.guestCount) : "—"],
    ["Budget (RM)", `${lead.budgetMin ?? "?"} – ${lead.budgetMax ?? "?"}`],
    ["Purpose", lead.purpose ?? "—"],
  ];

  return (
    <section className="max-w-4xl">
      <Link href="/admin/leads" className="text-sm text-white/50 hover:text-white">
        ← Leads
      </Link>
      <div className="mt-2 flex items-center justify-between">
        <h1 className="text-2xl font-semibold">{lead.referenceNo}</h1>
        <span className="text-sm text-white/50">{lead.status.toLowerCase()}</span>
      </div>
      <p className="mt-1 text-sm text-white/60">
        {lead.customer?.name} · {lead.customer?.email} · {lead.customer?.phone}
      </p>

      <div className="mt-6 grid gap-3 sm:grid-cols-2">
        {facts.map(([k, v]) => (
          <div key={k} className="rounded-lg border border-white/10 bg-white/[0.02] px-4 py-2 text-sm">
            <span className="text-white/45">{k}: </span>
            <span className="text-white/85">{v}</span>
          </div>
        ))}
      </div>

      {lead.theme ? (
        <p className="mt-4 text-sm text-white/70">
          <span className="text-white/45">Theme &amp; preferences: </span>
          {lead.theme}
        </p>
      ) : null}
      {lead.specialRequest ? (
        <p className="mt-2 text-sm text-white/70">
          <span className="text-white/45">Special request: </span>
          {lead.specialRequest}
        </p>
      ) : null}

      {/* Reference images */}
      {images.length > 0 ? (
        <div className="mt-6">
          <h2 className="text-sm uppercase tracking-wide text-white/50">Reference images</h2>
          <div className="mt-3 grid grid-cols-3 gap-3 sm:grid-cols-4">
            {images.map((a) => (
              // eslint-disable-next-line @next/next/no-img-element
              <img
                key={a.id}
                src={a.url}
                alt={a.filename ?? "reference"}
                className="aspect-square w-full rounded-lg border border-white/10 object-cover"
              />
            ))}
          </div>
        </div>
      ) : null}

      {/* Quotations */}
      <div className="mt-8 flex items-center justify-between">
        <h2 className="text-lg font-semibold">Quotations</h2>
        <form action={createAction}>
          <button className="rounded-md bg-accent px-4 py-2 text-sm font-medium text-ink transition hover:brightness-110">
            + Create quotation
          </button>
        </form>
      </div>
      <div className="mt-3 flex flex-col gap-2">
        {lead.quotations.length === 0 ? (
          <p className="text-sm text-white/40">
            None yet. Create one, then generate with AI or build it manually.
          </p>
        ) : (
          lead.quotations.map((q) => (
            <Link
              key={q.id}
              href={`/admin/quotations/${q.id}`}
              className="flex items-center justify-between rounded-lg border border-white/10 bg-white/[0.02] px-4 py-3 text-sm hover:bg-white/[0.04]"
            >
              <span className="text-white/90">{q.number}</span>
              <span className="text-white/50">
                {q.status.toLowerCase()} · RM {Number(q.total).toFixed(2)}
              </span>
            </Link>
          ))
        )}
      </div>
    </section>
  );
}
