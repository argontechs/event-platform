import Link from "next/link";
import { prisma } from "@event/db";
import { requireUser } from "@/lib/auth/rbac";
import { getActiveCompanyId } from "@/lib/tenant";
import { SelectCompanyNotice } from "@/components/admin/select-company-notice";

export const dynamic = "force-dynamic";

export default async function LeadsPage() {
  const user = await requireUser();
  const companyId = await getActiveCompanyId(user);

  return (
    <section>
      <h1 className="text-2xl font-semibold">Leads</h1>
      {!companyId ? (
        <div className="mt-6">
          <SelectCompanyNotice />
        </div>
      ) : (
        <LeadsTable companyId={companyId} />
      )}
    </section>
  );
}

async function LeadsTable({ companyId }: { companyId: string }) {
  const leads = await prisma.lead.findMany({
    where: { companyId },
    orderBy: { createdAt: "desc" },
    include: { customer: true },
    take: 100,
  });

  return (
    <div className="mt-6 overflow-hidden rounded-xl border border-white/10">
      <table className="w-full text-sm">
        <thead className="bg-white/[0.03] text-left text-white/50">
          <tr>
            <th className="px-4 py-3 font-medium">Reference</th>
            <th className="px-4 py-3 font-medium">Customer</th>
            <th className="px-4 py-3 font-medium">Event</th>
            <th className="px-4 py-3 font-medium">Date</th>
            <th className="px-4 py-3 font-medium">Status</th>
          </tr>
        </thead>
        <tbody>
          {leads.length === 0 ? (
            <tr>
              <td colSpan={5} className="px-4 py-8 text-center text-white/40">
                No leads yet.
              </td>
            </tr>
          ) : (
            leads.map((l) => (
              <tr key={l.id} className="border-t border-white/5 hover:bg-white/[0.02]">
                <td className="px-4 py-3">
                  <Link href={`/admin/leads/${l.id}`} className="text-white hover:text-accent">
                    {l.referenceNo}
                  </Link>
                </td>
                <td className="px-4 py-3 text-white/70">{l.customer?.name ?? "—"}</td>
                <td className="px-4 py-3 text-white/60">{l.eventType.toLowerCase()}</td>
                <td className="px-4 py-3 text-white/60">
                  {l.eventDate ? l.eventDate.toISOString().slice(0, 10) : "—"}
                </td>
                <td className="px-4 py-3 text-white/60">{l.status.toLowerCase()}</td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
}
