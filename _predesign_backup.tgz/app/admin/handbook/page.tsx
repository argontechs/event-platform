export const dynamic = "force-dynamic";

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="mt-8">
      <h2 className="text-lg font-semibold text-white">{title}</h2>
      <div className="mt-2 space-y-2 text-sm leading-relaxed text-white/70">{children}</div>
    </section>
  );
}

const steps = [
  ["Customer", "Visits the company's 3D site and submits the enquiry form → a Lead with a reference number."],
  ["Quotation", "Staff open the lead and build a quote — Generate with AI from the reference images, or manually. Everything is editable."],
  ["Accept & pay", "Customer opens the quote link, accepts, sees DuitNow/bank details, and uploads payment proof."],
  ["Confirm", "Staff confirm the payment → a Booking is created, an Invoice is issued, and the planning checklist is seeded."],
  ["Plan & deliver", "The planning dashboard tracks tasks, suppliers, run-sheet, locations and budget through to the event."],
];

export default function HandbookPage() {
  return (
    <section className="max-w-3xl">
      <h1 className="text-2xl font-semibold">Operator Handbook</h1>
      <p className="mt-1 text-sm text-white/50">How the platform works, end to end.</p>

      <Section title="The flow at a glance">
        <ol className="space-y-2">
          {steps.map(([k, v], i) => (
            <li key={i} className="flex gap-3">
              <span className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-accent/15 text-xs text-accent">
                {i + 1}
              </span>
              <span>
                <strong className="text-white/90">{k}.</strong> {v}
              </span>
            </li>
          ))}
        </ol>
      </Section>

      <Section title="Roles">
        <ul className="list-disc space-y-1 pl-5">
          <li><strong className="text-white/90">Super-admin</strong> — sees all companies + group reports; creates/edits companies; switch company via the top-left switcher.</li>
          <li><strong className="text-white/90">Company admin</strong> — manages their own company (settings, leads, quotes, invoices, planning).</li>
          <li><strong className="text-white/90">Sales</strong> — leads, quotations, invoices.</li>
          <li><strong className="text-white/90">Planner</strong> — the planning dashboard.</li>
        </ul>
      </Section>

      <Section title="Set up a company (super-admin)">
        <p>Companies → New company. Fill branding, SST (registered + rate), bank details + DuitNow QR, default profit %, quote/invoice prefixes, custom domain(s) and the OpenAI key. Saving applies it everywhere — site, quotes, invoices, emails.</p>
      </Section>

      <Section title="Enquiry → quotation">
        <p>Leads shows every enquiry with its reference images. Open one → Create quotation. Use <strong className="text-white/90">Generate with AI</strong> to draft a plan + analysed materials + priced lines from the images, or build it by hand. Each line is cost → profit % → selling price; set a default profit % and override per line. Toggle SST (per-company default, override per quote). Mark as sent to share the link.</p>
      </Section>

      <Section title="Payment → invoice">
        <p>The customer accepts the public quote, pays the deposit (DuitNow/bank) and uploads proof. Staff → Bookings → Confirm payment updates the balance, moves the event into planning, seeds the checklist, and issues a branded, printable invoice (per-company numbering + SST).</p>
      </Section>

      <Section title="Planning">
        <p>Planning lists upcoming events. Add and assign Locations, create events manually if needed, then on each event board tick off checklist tasks, add run-sheet entries and suppliers (with cost), and watch budget vs actual.</p>
      </Section>

      <Section title="Reports (super-admin)">
        <p>Group reports consolidates revenue, outstanding balances, leads, accepted quotes and upcoming events across all companies, with per-company breakdown and CSV export.</p>
      </Section>

      <p className="mt-10 text-xs text-white/40">
        Full version: <code>HANDBOOK.md</code> · Technical docs: <code>docs/</code> · Deploy: <code>DEPLOY.md</code>
      </p>
    </section>
  );
}
