import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { prisma } from "@event/db";
import { requireUser, isSuperAdmin } from "@/lib/auth/rbac";
import { sendQuotationAction } from "@/lib/quotations/actions";
import { QuotationEditor, type EditorLine } from "@/components/admin/quotation-editor";
import { AiGenerateButton } from "@/components/admin/ai-generate-button";

export const dynamic = "force-dynamic";

export default async function QuotationEditorPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const user = await requireUser();

  const quotation = await prisma.quotation.findUnique({
    where: { id },
    include: {
      company: true,
      items: { orderBy: { sortOrder: "asc" } },
      lead: true,
    },
  });
  if (!quotation) notFound();
  if (!isSuperAdmin(user) && user.companyId !== quotation.companyId) {
    redirect("/admin/quotations");
  }

  const aiDraft = quotation.leadId
    ? await prisma.aiDraft.findFirst({
        where: { leadId: quotation.leadId },
        orderBy: { createdAt: "desc" },
      })
    : null;
  const questions = Array.isArray(aiDraft?.questions)
    ? (aiDraft?.questions as string[])
    : [];

  const lines: EditorLine[] = quotation.items.map((it) => ({
    description: it.description,
    category: it.category ?? "",
    quantity: Number(it.quantity),
    unit: it.unit,
    costPrice: Number(it.costPrice),
    profitPercent: Number(it.profitPercent),
    referenceImageUrl: it.referenceImageUrl ?? "",
  }));

  return (
    <section className="max-w-5xl">
      <div className="flex items-center justify-between">
        <div>
          <Link href="/admin/quotations" className="text-sm text-white/50 hover:text-white">
            ← Quotations
          </Link>
          <h1 className="mt-1 text-2xl font-semibold">{quotation.number}</h1>
          <p className="text-sm text-white/50">
            {quotation.status.toLowerCase()} ·{" "}
            {quotation.company.sstRegistered
              ? `SST-registered (${Number(quotation.company.sstRate)}%)`
              : "not SST-registered"}
          </p>
        </div>
        <form action={sendQuotationAction.bind(null, quotation.id)}>
          <button className="rounded-md border border-white/15 px-4 py-2 text-sm text-white/80 transition hover:bg-white/5">
            Mark as sent
          </button>
        </form>
      </div>

      {/* AI vs manual */}
      <div className="mt-6 rounded-xl border border-white/10 bg-white/[0.02] p-5">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="text-sm font-medium text-white">Smart quotation</h2>
            <p className="text-xs text-white/50">
              Generate a draft from the reference images, or build it manually below — both stay editable.
            </p>
          </div>
          {quotation.lead ? (
            <AiGenerateButton quotationId={quotation.id} />
          ) : (
            <span className="text-xs text-white/40">No linked lead — manual only.</span>
          )}
        </div>

        {aiDraft?.planDraft ? (
          <div className="mt-4 rounded-lg border border-white/10 bg-black/20 p-4">
            <p className="text-xs uppercase tracking-wide text-accent">AI plan</p>
            <p className="mt-2 whitespace-pre-wrap text-sm text-white/75">{aiDraft.planDraft}</p>
            {questions.length > 0 ? (
              <div className="mt-3">
                <p className="text-xs uppercase tracking-wide text-accent">Questions to confirm</p>
                <ul className="mt-2 list-disc pl-5 text-sm text-white/70">
                  {questions.map((q, i) => (
                    <li key={i}>{q}</li>
                  ))}
                </ul>
              </div>
            ) : null}
          </div>
        ) : null}
      </div>

      {/* Editor — remounts when the quotation changes (e.g. after AI generate) */}
      <div className="mt-6">
        <QuotationEditor
          key={quotation.updatedAt.toISOString()}
          quotationId={quotation.id}
          sstRate={Number(quotation.sstRate)}
          initial={{
            lines,
            profitPercentDefault: Number(quotation.profitPercentDefault),
            discount: Number(quotation.discount),
            depositPercent: Number(quotation.depositPercent),
            sstApplied: quotation.sstApplied,
            notes: quotation.notes ?? "",
          }}
        />
      </div>
    </section>
  );
}
