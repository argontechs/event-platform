import Link from "next/link";
import { prisma } from "@event/db";
import { requireUser } from "@/lib/auth/rbac";
import { getActiveCompanyId } from "@/lib/tenant";
import { SelectCompanyNotice } from "@/components/admin/select-company-notice";

export const dynamic = "force-dynamic";

export default async function QuotationsPage() {
  const user = await requireUser();
  const companyId = await getActiveCompanyId(user);

  return (
    <section>
      <h1 className="text-2xl font-semibold">Quotations</h1>
      {!companyId ? (
        <div className="mt-6">
          <SelectCompanyNotice />
        </div>
      ) : (
        <QuotationsTable companyId={companyId} />
      )}
    </section>
  );
}

async function QuotationsTable({ companyId }: { companyId: string }) {
  const quotations = await prisma.quotation.findMany({
    where: { companyId },
    orderBy: { createdAt: "desc" },
    include: { customer: true },
    take: 100,
  });

  return (
    <div className="mt-6 overflow-hidden rounded-xl border border-white/10">
      <table className="w-full text-sm">
        <thead className="bg-white/[0.03] text-left text-white/50">
          <tr>
            <th className="px-4 py-3 font-medium">Number</th>
            <th className="px-4 py-3 font-medium">Customer</th>
            <th className="px-4 py-3 font-medium">Status</th>
            <th className="px-4 py-3 font-medium text-right">Total</th>
          </tr>
        </thead>
        <tbody>
          {quotations.length === 0 ? (
            <tr>
              <td colSpan={4} className="px-4 py-8 text-center text-white/40">
                No quotations yet.
              </td>
            </tr>
          ) : (
            quotations.map((q) => (
              <tr key={q.id} className="border-t border-white/5 hover:bg-white/[0.02]">
                <td className="px-4 py-3">
                  <Link href={`/admin/quotations/${q.id}`} className="text-white hover:text-accent">
                    {q.number}
                  </Link>
                </td>
                <td className="px-4 py-3 text-white/70">{q.customer?.name ?? "—"}</td>
                <td className="px-4 py-3 text-white/60">{q.status.toLowerCase()}</td>
                <td className="px-4 py-3 text-right text-white/80">
                  RM {Number(q.total).toFixed(2)}
                </td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
}
