import { prisma } from "@event/db";
import { requireUser, isSuperAdmin } from "@/lib/auth/rbac";
import { getActiveCompanyId } from "@/lib/tenant";

export const dynamic = "force-dynamic";

export default async function AdminDashboard() {
  const user = await requireUser();
  const superAdmin = isSuperAdmin(user);
  const activeCompanyId = await getActiveCompanyId(user);

  const company = activeCompanyId
    ? await prisma.company.findUnique({
        where: { id: activeCompanyId },
        select: { name: true },
      })
    : null;

  return (
    <section className="max-w-3xl">
      <h1 className="text-2xl font-semibold">Dashboard</h1>

      {superAdmin && !activeCompanyId ? (
        <p className="mt-3 rounded-lg border border-accent/30 bg-accent/10 px-4 py-3 text-sm text-white/80">
          You&apos;re signed in as <strong>group super-admin</strong>. Pick a company
          from the switcher above to manage it, or view consolidated reports
          (Phase 9).
        </p>
      ) : (
        <p className="mt-3 text-sm text-white/60">
          Active company:{" "}
          <strong className="text-white">{company?.name ?? "—"}</strong>
        </p>
      )}

      <div className="mt-6 grid gap-4 sm:grid-cols-2">
        {[
          { k: "Leads", v: "Phase 5" },
          { k: "Quotations (AI)", v: "Phase 6" },
          { k: "Invoices", v: "Phase 7" },
          { k: "Planning", v: "Phase 8" },
        ].map((c) => (
          <div
            key={c.k}
            className="rounded-xl border border-white/10 bg-white/[0.03] p-5"
          >
            <p className="text-sm text-white/60">{c.k}</p>
            <p className="mt-1 text-lg font-medium text-white/40">{c.v}</p>
          </div>
        ))}
      </div>
    </section>
  );
}
