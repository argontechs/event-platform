import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { prisma } from "@event/db";
import { requireUser, isSuperAdmin } from "@/lib/auth/rbac";
import { confirmPaymentAction } from "@/lib/bookings/actions";

export const dynamic = "force-dynamic";

function rm(n: number): string {
  return `RM ${n.toFixed(2)}`;
}

export default async function BookingDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const user = await requireUser();

  const booking = await prisma.booking.findUnique({
    where: { id },
    include: {
      customer: true,
      payments: { include: { attachments: true }, orderBy: { createdAt: "desc" } },
      invoices: { orderBy: { issuedAt: "desc" } },
      tasks: true,
    },
  });
  if (!booking) notFound();
  if (!isSuperAdmin(user) && user.companyId !== booking.companyId) redirect("/admin/bookings");

  return (
    <section className="max-w-4xl">
      <Link href="/admin/bookings" className="text-sm text-white/50 hover:text-white">
        ← Bookings
      </Link>
      <div className="mt-2 flex items-center justify-between">
        <h1 className="text-2xl font-semibold">{booking.title}</h1>
        <span className="text-sm text-white/50">{booking.status.replace("_", " ").toLowerCase()}</span>
      </div>
      <p className="mt-1 text-sm text-white/60">
        {booking.customer?.name} · {booking.eventType.toLowerCase()} ·{" "}
        {booking.eventDate ? booking.eventDate.toISOString().slice(0, 10) : "date TBC"}
      </p>

      <div className="mt-5 grid gap-3 sm:grid-cols-3">
        <Stat label="Total" value={rm(Number(booking.totalAmount))} />
        <Stat label="Deposit paid" value={rm(Number(booking.depositPaid))} />
        <Stat label="Balance due" value={rm(Number(booking.balanceDue))} />
      </div>

      {/* Payments */}
      <h2 className="mt-8 text-lg font-semibold">Payments</h2>
      <div className="mt-3 flex flex-col gap-2">
        {booking.payments.length === 0 ? (
          <p className="text-sm text-white/40">No payments recorded yet.</p>
        ) : (
          booking.payments.map((p) => (
            <div
              key={p.id}
              className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-white/10 bg-white/[0.02] px-4 py-3 text-sm"
            >
              <div>
                <span className="text-white/90">{rm(Number(p.amount))}</span>
                <span className="text-white/50"> · {p.type.toLowerCase()} · {p.method.toLowerCase()}</span>
                {p.reference ? <span className="text-white/40"> · {p.reference}</span> : null}
                {p.attachments[0] ? (
                  <a href={p.attachments[0].url} target="_blank" className="ml-2 text-accent hover:underline">
                    view proof
                  </a>
                ) : null}
              </div>
              <div className="flex items-center gap-3">
                <span className="text-white/50">{p.status.toLowerCase()}</span>
                {p.status === "PENDING" ? (
                  <form action={confirmPaymentAction.bind(null, p.id)}>
                    <button className="rounded-md bg-accent px-3 py-1.5 text-xs font-medium text-ink transition hover:brightness-110">
                      Confirm payment
                    </button>
                  </form>
                ) : null}
              </div>
            </div>
          ))
        )}
      </div>

      {/* Invoices */}
      <h2 className="mt-8 text-lg font-semibold">Invoices</h2>
      <div className="mt-3 flex flex-col gap-2">
        {booking.invoices.length === 0 ? (
          <p className="text-sm text-white/40">No invoice yet — confirm a payment to issue one.</p>
        ) : (
          booking.invoices.map((inv) => (
            <Link
              key={inv.id}
              href={`/admin/invoices/${inv.id}`}
              className="flex items-center justify-between rounded-lg border border-white/10 bg-white/[0.02] px-4 py-3 text-sm hover:bg-white/[0.04]"
            >
              <span className="text-white/90">{inv.number}</span>
              <span className="text-white/50">
                {inv.type.toLowerCase()} · {inv.status.toLowerCase()} · {rm(Number(inv.total))}
              </span>
            </Link>
          ))
        )}
      </div>

      <p className="mt-8 text-sm text-white/50">
        Planning tasks: {booking.tasks.length} ·{" "}
        <Link href="/planning" className="text-accent hover:underline">
          open planning →
        </Link>
      </p>
    </section>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl border border-white/10 bg-white/[0.02] p-4">
      <p className="text-xs text-white/50">{label}</p>
      <p className="mt-1 text-lg font-semibold text-white">{value}</p>
    </div>
  );
}
