import Link from "next/link";
import { prisma } from "@event/db";
import { requireUser } from "@/lib/auth/rbac";
import { getActiveCompanyId } from "@/lib/tenant";
import { SelectCompanyNotice } from "@/components/admin/select-company-notice";

export const dynamic = "force-dynamic";

export default async function BookingsPage() {
  const user = await requireUser();
  const companyId = await getActiveCompanyId(user);

  return (
    <section>
      <h1 className="text-2xl font-semibold">Bookings</h1>
      {!companyId ? (
        <div className="mt-6">
          <SelectCompanyNotice />
        </div>
      ) : (
        <BookingsTable companyId={companyId} />
      )}
    </section>
  );
}

async function BookingsTable({ companyId }: { companyId: string }) {
  const bookings = await prisma.booking.findMany({
    where: { companyId },
    orderBy: { createdAt: "desc" },
    include: { customer: true },
    take: 100,
  });

  return (
    <div className="mt-6 overflow-hidden rounded-xl border border-white/10">
      <table className="w-full text-sm">
        <thead className="bg-white/[0.03] text-left text-white/50">
          <tr>
            <th className="px-4 py-3 font-medium">Event</th>
            <th className="px-4 py-3 font-medium">Customer</th>
            <th className="px-4 py-3 font-medium">Status</th>
            <th className="px-4 py-3 font-medium text-right">Balance</th>
          </tr>
        </thead>
        <tbody>
          {bookings.length === 0 ? (
            <tr>
              <td colSpan={4} className="px-4 py-8 text-center text-white/40">
                No bookings yet.
              </td>
            </tr>
          ) : (
            bookings.map((b) => (
              <tr key={b.id} className="border-t border-white/5 hover:bg-white/[0.02]">
                <td className="px-4 py-3">
                  <Link href={`/admin/bookings/${b.id}`} className="text-white hover:text-accent">
                    {b.title}
                  </Link>
                </td>
                <td className="px-4 py-3 text-white/70">{b.customer?.name ?? "—"}</td>
                <td className="px-4 py-3 text-white/60">{b.status.replace("_", " ").toLowerCase()}</td>
                <td className="px-4 py-3 text-right text-white/80">RM {Number(b.balanceDue).toFixed(2)}</td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
}
