import Link from "next/link";
import { prisma } from "@event/db";
import { requireUser, isSuperAdmin } from "@/lib/auth/rbac";
import { getActiveCompanyId } from "@/lib/tenant";
import { logoutAction } from "@/lib/auth/actions";
import { CompanySwitcher } from "@/components/admin/company-switcher";

export const dynamic = "force-dynamic";

const NAV = [
  { href: "/admin", label: "Dashboard" },
  { href: "/admin/leads", label: "Leads" },
  { href: "/admin/quotations", label: "Quotations" },
  { href: "/admin/bookings", label: "Bookings" },
  { href: "/admin/invoices", label: "Invoices" },
  { href: "/planning", label: "Planning" },
  { href: "/admin/handbook", label: "Handbook" },
];

export default async function AdminLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const user = await requireUser();
  const superAdmin = isSuperAdmin(user);
  const activeCompanyId = await getActiveCompanyId(user);

  const companies = superAdmin
    ? await prisma.company.findMany({
        select: { id: true, name: true },
        orderBy: { name: "asc" },
      })
    : [];

  let nav = NAV;
  if (superAdmin) {
    nav = [
      ...NAV.slice(0, 1),
      { href: "/admin/companies", label: "Companies" },
      { href: "/admin/reports", label: "Group reports" },
      ...NAV.slice(1),
    ];
  } else if (user.role === "COMPANY_ADMIN" && user.companyId) {
    nav = [...NAV, { href: `/admin/companies/${user.companyId}`, label: "Company settings" }];
  }

  return (
    <div className="flex min-h-screen">
      <aside className="hidden w-60 shrink-0 border-r border-white/10 bg-white/[0.02] p-5 md:block">
        <div className="mb-8">
          <p className="text-xs uppercase tracking-[0.25em] text-accent">Back Office</p>
          <p className="mt-1 text-sm text-white/50">Event &amp; Decoration</p>
        </div>
        <nav className="flex flex-col gap-1">
          {nav.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className="rounded-md px-3 py-2 text-sm text-white/70 transition hover:bg-white/5 hover:text-white"
            >
              {item.label}
            </Link>
          ))}
        </nav>
      </aside>

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="flex items-center justify-between gap-4 border-b border-white/10 px-6 py-3">
          <div className="flex items-center gap-3">
            {superAdmin ? (
              <CompanySwitcher companies={companies} activeId={activeCompanyId} />
            ) : (
              <span className="text-sm text-white/60">{user.name}</span>
            )}
          </div>
          <div className="flex items-center gap-4">
            <span className="text-xs text-white/40">
              {user.email} · {user.role.replace("_", " ").toLowerCase()}
            </span>
            <form action={logoutAction}>
              <button className="rounded-md border border-white/15 px-3 py-1.5 text-sm text-white/80 transition hover:bg-white/5">
                Log out
              </button>
            </form>
          </div>
        </header>

        <main className="flex-1 p-6">{children}</main>
      </div>
    </div>
  );
}
