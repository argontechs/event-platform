import Link from "next/link";
import { prisma } from "@event/db";
import { requireUser } from "@/lib/auth/rbac";
import { getActiveCompanyId } from "@/lib/tenant";
import { SelectCompanyNotice } from "@/components/admin/select-company-notice";

export const dynamic = "force-dynamic";

export default async function InvoicesPage() {
  const user = await requireUser();
  const companyId = await getActiveCompanyId(user);

  return (
    <section>
      <h1 className="text-2xl font-semibold">Invoices</h1>
      {!companyId ? (
        <div className="mt-6">
          <SelectCompanyNotice />
        </div>
      ) : (
        <InvoicesTable companyId={companyId} />
      )}
    </section>
  );
}

async function InvoicesTable({ companyId }: { companyId: string }) {
  const invoices = await prisma.invoice.findMany({
    where: { companyId },
    orderBy: { issuedAt: "desc" },
    take: 100,
  });

  return (
    <div className="mt-6 overflow-hidden rounded-xl border border-white/10">
      <table className="w-full text-sm">
        <thead className="bg-white/[0.03] text-left text-white/50">
          <tr>
            <th className="px-4 py-3 font-medium">Number</th>
            <th className="px-4 py-3 font-medium">Type</th>
            <th className="px-4 py-3 font-medium">Status</th>
            <th className="px-4 py-3 font-medium text-right">Total</th>
            <th className="px-4 py-3 font-medium text-right">Balance</th>
          </tr>
        </thead>
        <tbody>
          {invoices.length === 0 ? (
            <tr>
              <td colSpan={5} className="px-4 py-8 text-center text-white/40">
                No invoices yet.
              </td>
            </tr>
          ) : (
            invoices.map((inv) => (
              <tr key={inv.id} className="border-t border-white/5 hover:bg-white/[0.02]">
                <td className="px-4 py-3">
                  <Link href={`/admin/invoices/${inv.id}`} className="text-white hover:text-accent">
                    {inv.number}
                  </Link>
                </td>
                <td className="px-4 py-3 text-white/60">{inv.type.toLowerCase()}</td>
                <td className="px-4 py-3 text-white/60">{inv.status.toLowerCase()}</td>
                <td className="px-4 py-3 text-right text-white/80">RM {Number(inv.total).toFixed(2)}</td>
                <td className="px-4 py-3 text-right text-white/80">RM {Number(inv.balanceDue).toFixed(2)}</td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
}
