import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { prisma } from "@event/db";
import { requireUser, isSuperAdmin } from "@/lib/auth/rbac";

export const dynamic = "force-dynamic";

type InvoiceItem = {
  description: string;
  quantity: number;
  unit: string;
  unitPrice: number;
  lineTotal: number;
};
type CustomerSnapshot = { name?: string; email?: string; phone?: string };

function rm(n: number): string {
  return `RM ${n.toFixed(2)}`;
}

export default async function InvoicePage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const user = await requireUser();

  const inv = await prisma.invoice.findUnique({
    where: { id },
    include: { company: true },
  });
  if (!inv) notFound();
  if (!isSuperAdmin(user) && user.companyId !== inv.companyId) redirect("/admin/invoices");

  const items = Array.isArray(inv.items) ? (inv.items as unknown as InvoiceItem[]) : [];
  const cust = (inv.customerSnapshot ?? {}) as CustomerSnapshot;
  const c = inv.company;

  return (
    <section className="mx-auto max-w-2xl">
      <div className="mb-4 flex items-center justify-between print:hidden">
        <Link href="/admin/invoices" className="text-sm text-white/50 hover:text-white">
          ← Invoices
        </Link>
      </div>

      <div className="rounded-2xl border border-white/10 bg-white text-zinc-900 p-8 shadow-xl">
        {/* Header */}
        <div className="flex items-start justify-between">
          <div>
            <p className="text-xl font-bold">{c.name}</p>
            {c.legalName ? <p className="text-sm text-zinc-500">{c.legalName}</p> : null}
            {c.ssmRegNo ? <p className="text-xs text-zinc-400">SSM: {c.ssmRegNo}</p> : null}
            {c.sstRegistered && c.sstRegNo ? (
              <p className="text-xs text-zinc-400">SST: {c.sstRegNo}</p>
            ) : null}
          </div>
          <div className="text-right">
            <p className="text-lg font-semibold">INVOICE</p>
            <p className="text-sm text-zinc-600">{inv.number}</p>
            <p className="text-xs text-zinc-400">{inv.issuedAt.toISOString().slice(0, 10)}</p>
            <span className="mt-1 inline-block rounded bg-zinc-100 px-2 py-0.5 text-xs uppercase text-zinc-600">
              {inv.type.toLowerCase()} · {inv.status.toLowerCase()}
            </span>
          </div>
        </div>

        {/* Bill to */}
        <div className="mt-6 text-sm">
          <p className="text-zinc-400">Bill to</p>
          <p className="font-medium">{cust.name ?? "—"}</p>
          {cust.email ? <p className="text-zinc-500">{cust.email}</p> : null}
          {cust.phone ? <p className="text-zinc-500">{cust.phone}</p> : null}
        </div>

        {/* Items */}
        <table className="mt-6 w-full text-sm">
          <thead>
            <tr className="border-b border-zinc-200 text-left text-zinc-500">
              <th className="py-2 font-medium">Description</th>
              <th className="py-2 text-right font-medium">Qty</th>
              <th className="py-2 text-right font-medium">Unit</th>
              <th className="py-2 text-right font-medium">Amount</th>
            </tr>
          </thead>
          <tbody>
            {items.map((it, i) => (
              <tr key={i} className="border-b border-zinc-100">
                <td className="py-2">{it.description}</td>
                <td className="py-2 text-right">{it.quantity} {it.unit}</td>
                <td className="py-2 text-right">{rm(it.unitPrice)}</td>
                <td className="py-2 text-right">{rm(it.lineTotal)}</td>
              </tr>
            ))}
          </tbody>
        </table>

        {/* Totals */}
        <div className="mt-4 ml-auto max-w-xs space-y-1 text-sm">
          <Row label="Subtotal" value={rm(Number(inv.subtotal))} />
          {inv.sstApplied ? <Row label={`SST (${Number(inv.sstRate)}%)`} value={rm(Number(inv.sstAmount))} /> : null}
          <div className="my-1 border-t border-zinc-200" />
          <Row label="Total" value={rm(Number(inv.total))} strong />
          <Row label="Amount paid" value={rm(Number(inv.amountPaid))} />
          <Row label="Balance due" value={rm(Number(inv.balanceDue))} strong />
        </div>

        <div className="mt-8 border-t border-zinc-200 pt-4 text-xs text-zinc-500">
          {c.bankName ? (
            <p>
              Payment: {c.bankName} · {c.bankAccountName} · {c.bankAccountNo}
            </p>
          ) : null}
          <p className="mt-1">Thank you for your business.</p>
        </div>
      </div>
    </section>
  );
}

function Row({ label, value, strong }: { label: string; value: string; strong?: boolean }) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-zinc-500">{label}</span>
      <span className={strong ? "font-semibold text-zinc-900" : "text-zinc-700"}>{value}</span>
    </div>
  );
}
