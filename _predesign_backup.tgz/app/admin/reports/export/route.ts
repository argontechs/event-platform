import { NextResponse } from "next/server";
import { getSession } from "@/lib/auth/session";
import { buildGroupReport } from "@/lib/reports/group";

export const dynamic = "force-dynamic";

export async function GET() {
  const user = await getSession();
  if (!user || user.role !== "SUPER_ADMIN") {
    return new NextResponse("Forbidden", { status: 403 });
  }

  const { rows, totals } = await buildGroupReport();
  const header = ["Company", "Leads", "Accepted", "Active events", "Upcoming", "Revenue", "Outstanding"];
  const lines = [
    header.join(","),
    ...rows.map((r) =>
      [r.name, r.leads, r.accepted, r.activeEvents, r.upcoming, r.revenue.toFixed(2), r.outstanding.toFixed(2)]
        .map((v) => `"${String(v).replace(/"/g, '""')}"`)
        .join(","),
    ),
    ["Total", totals.leads, totals.accepted, totals.activeEvents, totals.upcoming, totals.revenue.toFixed(2), totals.outstanding.toFixed(2)]
      .map((v) => `"${v}"`)
      .join(","),
  ];

  return new NextResponse(lines.join("\n"), {
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": 'attachment; filename="group-report.csv"',
    },
  });
}
