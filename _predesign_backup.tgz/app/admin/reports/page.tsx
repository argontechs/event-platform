import Link from "next/link";
import { requireSuperAdmin } from "@/lib/auth/rbac";
import { buildGroupReport } from "@/lib/reports/group";

export const dynamic = "force-dynamic";

function rm(n: number): string {
  return `RM ${n.toFixed(2)}`;
}

export default async function GroupReportsPage() {
  await requireSuperAdmin();
  const { rows, totals } = await buildGroupReport();

  return (
    <section>
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold">Group reports</h1>
        <a
          href="/admin/reports/export"
          className="rounded-md border border-white/15 px-4 py-2 text-sm text-white/80 transition hover:bg-white/5"
        >
          Export CSV
        </a>
      </div>
      <p className="mt-1 text-sm text-white/50">Consolidated across all companies.</p>

      <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Card label="Revenue (confirmed)" value={rm(totals.revenue)} />
        <Card label="Outstanding balances" value={rm(totals.outstanding)} />
        <Card label="Accepted quotes" value={String(totals.accepted)} />
        <Card label="Upcoming events" value={String(totals.upcoming)} />
      </div>

      <div className="mt-8 overflow-x-auto rounded-xl border border-white/10">
        <table className="w-full min-w-[720px] text-sm">
          <thead className="bg-white/[0.03] text-left text-white/50">
            <tr>
              <th className="px-4 py-3 font-medium">Company</th>
              <th className="px-4 py-3 font-medium text-right">Leads</th>
              <th className="px-4 py-3 font-medium text-right">Accepted</th>
              <th className="px-4 py-3 font-medium text-right">Active events</th>
              <th className="px-4 py-3 font-medium text-right">Upcoming</th>
              <th className="px-4 py-3 font-medium text-right">Revenue</th>
              <th className="px-4 py-3 font-medium text-right">Outstanding</th>
            </tr>
          </thead>
          <tbody>
            {rows.length === 0 ? (
              <tr>
                <td colSpan={7} className="px-4 py-8 text-center text-white/40">
                  No companies yet.
                </td>
              </tr>
            ) : (
              rows.map((r) => (
                <tr key={r.companyId} className="border-t border-white/5 hover:bg-white/[0.02]">
                  <td className="px-4 py-3">
                    <Link href={`/admin/companies/${r.companyId}`} className="text-white hover:text-accent">
                      {r.name}
                    </Link>
                  </td>
                  <td className="px-4 py-3 text-right text-white/70">{r.leads}</td>
                  <td className="px-4 py-3 text-right text-white/70">{r.accepted}</td>
                  <td className="px-4 py-3 text-right text-white/70">{r.activeEvents}</td>
                  <td className="px-4 py-3 text-right text-white/70">{r.upcoming}</td>
                  <td className="px-4 py-3 text-right text-white/80">{rm(r.revenue)}</td>
                  <td className="px-4 py-3 text-right text-white/80">{rm(r.outstanding)}</td>
                </tr>
              ))
            )}
          </tbody>
          {rows.length > 0 ? (
            <tfoot>
              <tr className="border-t border-white/15 font-medium">
                <td className="px-4 py-3 text-white">Total</td>
                <td className="px-4 py-3 text-right text-white/80">{totals.leads}</td>
                <td className="px-4 py-3 text-right text-white/80">{totals.accepted}</td>
                <td className="px-4 py-3 text-right text-white/80">{totals.activeEvents}</td>
                <td className="px-4 py-3 text-right text-white/80">{totals.upcoming}</td>
                <td className="px-4 py-3 text-right text-white">{rm(totals.revenue)}</td>
                <td className="px-4 py-3 text-right text-white">{rm(totals.outstanding)}</td>
              </tr>
            </tfoot>
          ) : null}
        </table>
      </div>
    </section>
  );
}

function Card({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl border border-white/10 bg-white/[0.03] p-5">
      <p className="text-sm text-white/55">{label}</p>
      <p className="mt-1 text-xl font-semibold text-white">{value}</p>
    </div>
  );
}
