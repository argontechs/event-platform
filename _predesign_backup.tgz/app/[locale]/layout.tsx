import { headers } from "next/headers";
import { notFound } from "next/navigation";
import { isLocale } from "@/lib/i18n/config";
import { getDictionary } from "@/lib/i18n/dictionaries";
import { getCompanyByHost } from "@/lib/tenant";
import { SiteNav } from "@/components/site/site-nav";
import { SiteFooter } from "@/components/site/site-footer";

export const dynamic = "force-dynamic";

export default async function SiteLayout({
  children,
  params,
}: {
  children: React.ReactNode;
  params: Promise<{ locale: string }>;
}) {
  const { locale } = await params;
  if (!isLocale(locale)) notFound();

  const dict = getDictionary(locale);
  const host = (await headers()).get("host");
  const company = await getCompanyByHost(host).catch(() => null);

  const brandName = company?.name ?? "Your Event Co.";
  const primary = company?.brandPrimary ?? "#c9a35b";
  const secondary = company?.brandSecondary ?? "#2a2440";

  return (
    <div
      style={
        { "--brand": primary, "--brand-2": secondary } as React.CSSProperties
      }
    >
      <SiteNav locale={locale} dict={dict.nav} brandName={brandName} />
      {children}
      <SiteFooter dict={dict.footer} brandName={brandName} />
    </div>
  );
}
