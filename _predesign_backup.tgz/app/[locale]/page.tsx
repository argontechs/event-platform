import Link from "next/link";
import { notFound } from "next/navigation";
import { isLocale } from "@/lib/i18n/config";
import { getDictionary } from "@/lib/i18n/dictionaries";
import { Hero3D } from "@/components/site/hero";

export const dynamic = "force-dynamic";

export default async function HomePage({
  params,
}: {
  params: Promise<{ locale: string }>;
}) {
  const { locale } = await params;
  if (!isLocale(locale)) notFound();
  const dict = getDictionary(locale);
  const base = `/${locale}`;

  return (
    <>
      {/* Hero */}
      <section className="relative flex min-h-screen items-center overflow-hidden">
        <div
          className="absolute inset-0"
          style={{
            background:
              "radial-gradient(60% 60% at 30% 20%, color-mix(in oklab, var(--brand) 22%, transparent), transparent 60%), radial-gradient(50% 50% at 80% 90%, color-mix(in oklab, var(--brand-2) 35%, transparent), transparent 60%), #0b0b10",
          }}
        />
        <div className="absolute inset-0">
          <Hero3D />
        </div>

        <div className="relative mx-auto w-full max-w-6xl px-6">
          <p className="text-xs uppercase tracking-[0.35em] text-[var(--brand)]">
            {dict.hero.eyebrow}
          </p>
          <h1 className="mt-4 max-w-3xl text-[clamp(2.5rem,1rem+6vw,5.5rem)] font-semibold leading-[1.02]">
            {dict.hero.title}
          </h1>
          <p className="mt-6 max-w-xl text-lg text-white/70">
            {dict.hero.subtitle}
          </p>
          <div className="mt-9 flex flex-wrap gap-4">
            <Link
              href={`${base}/contact`}
              className="rounded-full px-6 py-3 font-medium text-ink transition hover:brightness-110"
              style={{ backgroundColor: "var(--brand)" }}
            >
              {dict.hero.cta}
            </Link>
            <Link
              href={`${base}/portfolio`}
              className="rounded-full border border-white/20 px-6 py-3 font-medium text-white/90 transition hover:bg-white/5"
            >
              {dict.hero.secondary}
            </Link>
          </div>
        </div>
      </section>

      {/* Services */}
      <section className="mx-auto max-w-6xl px-6 py-24">
        <h2 className="text-3xl font-semibold">{dict.services.title}</h2>
        <p className="mt-2 max-w-xl text-white/60">{dict.services.subtitle}</p>
        <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {dict.services.items.map((s, i) => (
            <div
              key={i}
              className="group rounded-2xl border border-white/10 bg-white/[0.03] p-6 transition hover:-translate-y-1 hover:border-[var(--brand)]/40"
            >
              <span className="text-sm text-[var(--brand)]">0{i + 1}</span>
              <h3 className="mt-3 text-lg font-medium">{s.title}</h3>
              <p className="mt-2 text-sm text-white/55">{s.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Showcase teaser */}
      <section className="mx-auto max-w-6xl px-6 pb-24">
        <div className="flex items-end justify-between">
          <div>
            <h2 className="text-3xl font-semibold">{dict.showcase.title}</h2>
            <p className="mt-2 text-white/60">{dict.showcase.subtitle}</p>
          </div>
          <Link href={`${base}/portfolio`} className="text-sm text-[var(--brand)] hover:underline">
            {dict.nav.portfolio} →
          </Link>
        </div>
        <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {Array.from({ length: 6 }).map((_, i) => (
            <div
              key={i}
              className="aspect-[4/3] rounded-2xl border border-white/10 bg-gradient-to-br from-white/[0.06] to-transparent"
            />
          ))}
        </div>
      </section>

      {/* About + CTA */}
      <section className="mx-auto max-w-6xl px-6 pb-28">
        <div className="rounded-3xl border border-white/10 bg-white/[0.03] p-10">
          <h2 className="text-3xl font-semibold">{dict.about.title}</h2>
          <p className="mt-3 max-w-2xl text-white/65">{dict.about.body}</p>
          <Link
            href={`${base}/contact`}
            className="mt-7 inline-block rounded-full px-6 py-3 font-medium text-ink transition hover:brightness-110"
            style={{ backgroundColor: "var(--brand)" }}
          >
            {dict.contact.cta}
          </Link>
        </div>
      </section>
    </>
  );
}
