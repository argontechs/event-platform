import { LoginForm } from "./login-form";

export const metadata = { title: "Sign in · Event Platform" };

export default function LoginPage() {
  return (
    <main className="mx-auto flex min-h-screen max-w-md flex-col justify-center px-6">
      <p className="text-xs uppercase tracking-[0.3em] text-accent">Back Office</p>
      <h1 className="mt-2 text-3xl font-semibold">Sign in</h1>
      <p className="mt-1 text-sm text-white/50">
        Group &amp; per-company access to leads, quotes, invoices and planning.
      </p>
      <div className="mt-8 rounded-2xl border border-white/10 bg-white/[0.03] p-6">
        <LoginForm />
      </div>
    </main>
  );
}
