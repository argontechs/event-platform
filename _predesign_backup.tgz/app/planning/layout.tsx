import Link from "next/link";
import { requireUser } from "@/lib/auth/rbac";
import { logoutAction } from "@/lib/auth/actions";

export const dynamic = "force-dynamic";

export default async function PlanningLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const user = await requireUser();

  return (
    <div className="flex min-h-screen flex-col">
      <header className="flex items-center justify-between border-b border-white/10 px-6 py-3">
        <div className="flex items-center gap-5">
          <p className="text-xs uppercase tracking-[0.25em] text-accent">
            Planning
          </p>
          <Link href="/planning" className="text-sm text-white/60 hover:text-white">
            Overview
          </Link>
          <Link href="/planning/locations" className="text-sm text-white/60 hover:text-white">
            Locations
          </Link>
          <Link href="/planning/events/new" className="text-sm text-white/60 hover:text-white">
            + New event
          </Link>
          <Link href="/admin" className="text-sm text-white/40 hover:text-white">
            ← Back office
          </Link>
        </div>
        <div className="flex items-center gap-4">
          <span className="text-xs text-white/40">{user.name}</span>
          <form action={logoutAction}>
            <button className="rounded-md border border-white/15 px-3 py-1.5 text-sm text-white/80 transition hover:bg-white/5">
              Log out
            </button>
          </form>
        </div>
      </header>
      <main className="flex-1 p-6">{children}</main>
    </div>
  );
}
