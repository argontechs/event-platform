import Link from "next/link";
import { prisma } from "@event/db";
import { requireUser } from "@/lib/auth/rbac";
import { getActiveCompanyId } from "@/lib/tenant";
import { SelectCompanyNotice } from "@/components/admin/select-company-notice";

export const dynamic = "force-dynamic";

export default async function PlanningHome() {
  const user = await requireUser();
  const companyId = await getActiveCompanyId(user);

  return (
    <section>
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold">Event Planning</h1>
        <Link
          href="/planning/events/new"
          className="rounded-md bg-accent px-4 py-2 text-sm font-medium text-ink transition hover:brightness-110"
        >
          + New event
        </Link>
      </div>
      {!companyId ? (
        <div className="mt-6">
          <SelectCompanyNotice />
        </div>
      ) : (
        <Events companyId={companyId} />
      )}
    </section>
  );
}

async function Events({ companyId }: { companyId: string }) {
  const bookings = await prisma.booking.findMany({
    where: { companyId, status: { notIn: ["COMPLETED", "CLOSED", "CANCELLED"] } },
    orderBy: [{ eventDate: "asc" }, { createdAt: "desc" }],
    include: { location: true, customer: true, tasks: true },
    take: 100,
  });

  if (bookings.length === 0) {
    return <p className="mt-6 text-sm text-white/40">No upcoming events. Create one or confirm a quote.</p>;
  }

  return (
    <div className="mt-6 grid gap-3">
      {bookings.map((b) => {
        const done = b.tasks.filter((t) => t.status === "DONE").length;
        return (
          <Link
            key={b.id}
            href={`/planning/${b.id}`}
            className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-white/10 bg-white/[0.03] px-5 py-4 hover:border-accent/40"
          >
            <div>
              <p className="font-medium text-white">{b.title}</p>
              <p className="text-sm text-white/50">
                {b.eventDate ? b.eventDate.toISOString().slice(0, 10) : "date TBC"}
                {b.location ? ` · ${b.location.name}` : b.venueText ? ` · ${b.venueText}` : ""}
                {b.customer ? ` · ${b.customer.name}` : ""}
              </p>
            </div>
            <div className="text-right text-sm">
              <p className="text-white/60">{b.status.replace("_", " ").toLowerCase()}</p>
              <p className="text-white/40">
                {done}/{b.tasks.length} tasks
              </p>
            </div>
          </Link>
        );
      })}
    </div>
  );
}
