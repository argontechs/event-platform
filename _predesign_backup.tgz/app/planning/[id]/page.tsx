import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { prisma } from "@event/db";
import { requireUser, isSuperAdmin } from "@/lib/auth/rbac";
import {
  updateEventAction,
  addTaskAction,
  toggleTaskAction,
  deleteTaskAction,
  addRunSheetAction,
  addSupplierToEventAction,
} from "@/lib/planning/actions";
import { EventForm, type EventValues } from "@/components/planning/event-form";

export const dynamic = "force-dynamic";

function rm(n: number): string {
  return `RM ${n.toFixed(2)}`;
}

const field =
  "rounded-md border border-white/15 bg-white/5 px-3 py-2 text-sm text-white outline-none focus:border-accent";

export default async function EventBoardPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const user = await requireUser();

  const booking = await prisma.booking.findUnique({
    where: { id },
    include: {
      location: true,
      customer: true,
      tasks: { orderBy: { sortOrder: "asc" } },
      runSheet: { orderBy: { sortOrder: "asc" } },
      suppliers: { include: { supplier: true } },
    },
  });
  if (!booking) notFound();
  if (!isSuperAdmin(user) && user.companyId !== booking.companyId) redirect("/planning");

  const locations = await prisma.location.findMany({
    where: { companyId: booking.companyId },
    orderBy: { name: "asc" },
    select: { id: true, name: true },
  });

  const supplierCost = booking.suppliers.reduce((sum, s) => sum + Number(s.cost ?? 0), 0);
  const total = Number(booking.totalAmount);
  const margin = total - supplierCost;
  const doneTasks = booking.tasks.filter((t) => t.status === "DONE").length;

  const values: EventValues = {
    title: booking.title,
    eventType: booking.eventType,
    eventDate: booking.eventDate ? booking.eventDate.toISOString().slice(0, 10) : "",
    locationId: booking.locationId ?? "",
    venueText: booking.venueText ?? "",
    totalAmount: String(total),
    status: booking.status,
  };

  return (
    <section className="max-w-5xl">
      <Link href="/planning" className="text-sm text-white/50 hover:text-white">
        ← Planning
      </Link>
      <h1 className="mt-2 text-2xl font-semibold">{booking.title}</h1>
      <p className="mt-1 text-sm text-white/50">
        {booking.status.replace("_", " ").toLowerCase()} ·{" "}
        {booking.eventDate ? booking.eventDate.toISOString().slice(0, 10) : "date TBC"}
        {booking.location ? ` · ${booking.location.name}` : ""}
      </p>

      {/* Budget */}
      <div className="mt-5 grid gap-3 sm:grid-cols-3">
        <Stat label="Event value" value={rm(total)} />
        <Stat label="Supplier cost" value={rm(supplierCost)} />
        <Stat label="Margin" value={rm(margin)} />
      </div>

      <div className="mt-8 grid gap-8 lg:grid-cols-2">
        {/* Tasks */}
        <div>
          <h2 className="text-lg font-semibold">
            Checklist <span className="text-sm font-normal text-white/40">({doneTasks}/{booking.tasks.length})</span>
          </h2>
          <div className="mt-3 flex flex-col gap-2">
            {booking.tasks.map((t) => (
              <div key={t.id} className="flex items-center gap-3 rounded-lg border border-white/10 bg-white/[0.02] px-3 py-2 text-sm">
                <form action={toggleTaskAction.bind(null, t.id)}>
                  <button
                    className={`flex h-5 w-5 items-center justify-center rounded border ${
                      t.status === "DONE" ? "border-accent bg-accent text-ink" : "border-white/30 text-transparent"
                    }`}
                    aria-label="Toggle task"
                  >
                    ✓
                  </button>
                </form>
                <span className={`flex-1 ${t.status === "DONE" ? "text-white/40 line-through" : "text-white/85"}`}>
                  {t.title}
                  {t.category ? <span className="ml-2 text-xs text-white/30">{t.category}</span> : null}
                </span>
                <form action={deleteTaskAction.bind(null, t.id)}>
                  <button className="text-white/30 hover:text-red-400" aria-label="Delete task">✕</button>
                </form>
              </div>
            ))}
          </div>
          <form action={addTaskAction.bind(null, booking.id)} className="mt-3 flex flex-wrap gap-2">
            <input name="title" placeholder="New task" className={`${field} flex-1`} />
            <input name="category" placeholder="Category" className={`${field} w-28`} />
            <button className="rounded-md border border-white/15 px-3 py-2 text-sm text-white/80 hover:bg-white/5">Add</button>
          </form>
        </div>

        {/* Run sheet */}
        <div>
          <h2 className="text-lg font-semibold">Run sheet</h2>
          <div className="mt-3 flex flex-col gap-2">
            {booking.runSheet.length === 0 ? (
              <p className="text-sm text-white/40">No entries yet.</p>
            ) : (
              booking.runSheet.map((r) => (
                <div key={r.id} className="flex gap-3 rounded-lg border border-white/10 bg-white/[0.02] px-3 py-2 text-sm">
                  <span className="w-14 text-white/50">{r.time ?? "—"}</span>
                  <span className="flex-1 text-white/85">{r.activity}</span>
                  {r.owner ? <span className="text-white/40">{r.owner}</span> : null}
                </div>
              ))
            )}
          </div>
          <form action={addRunSheetAction.bind(null, booking.id)} className="mt-3 flex flex-wrap gap-2">
            <input name="time" placeholder="14:30" className={`${field} w-20`} />
            <input name="activity" placeholder="Activity" className={`${field} flex-1`} />
            <input name="owner" placeholder="Owner" className={`${field} w-24`} />
            <button className="rounded-md border border-white/15 px-3 py-2 text-sm text-white/80 hover:bg-white/5">Add</button>
          </form>
        </div>

        {/* Suppliers */}
        <div>
          <h2 className="text-lg font-semibold">Suppliers</h2>
          <div className="mt-3 flex flex-col gap-2">
            {booking.suppliers.length === 0 ? (
              <p className="text-sm text-white/40">None assigned.</p>
            ) : (
              booking.suppliers.map((bs) => (
                <div key={bs.id} className="flex items-center justify-between rounded-lg border border-white/10 bg-white/[0.02] px-3 py-2 text-sm">
                  <span className="text-white/85">
                    {bs.supplier.name}
                    {bs.supplier.type ? <span className="ml-2 text-xs text-white/30">{bs.supplier.type}</span> : null}
                  </span>
                  <span className="text-white/60">{rm(Number(bs.cost ?? 0))}</span>
                </div>
              ))
            )}
          </div>
          <form action={addSupplierToEventAction.bind(null, booking.id)} className="mt-3 grid grid-cols-2 gap-2">
            <input name="name" placeholder="Supplier name" className={field} />
            <input name="type" placeholder="Type (florist…)" className={field} />
            <input name="cost" type="number" step="0.01" placeholder="Cost (RM)" className={field} />
            <input name="phone" placeholder="Phone" className={field} />
            <button className="col-span-2 rounded-md border border-white/15 px-3 py-2 text-sm text-white/80 hover:bg-white/5">
              Add supplier
            </button>
          </form>
        </div>

        {/* Event details */}
        <div>
          <h2 className="text-lg font-semibold">Event details</h2>
          <div className="mt-3">
            <EventForm
              action={updateEventAction.bind(null, booking.id)}
              locations={locations}
              initial={values}
              submitLabel="Save details"
              showStatus
            />
          </div>
        </div>
      </div>
    </section>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl border border-white/10 bg-white/[0.02] p-4">
      <p className="text-xs text-white/50">{label}</p>
      <p className="mt-1 text-lg font-semibold text-white">{value}</p>
    </div>
  );
}
